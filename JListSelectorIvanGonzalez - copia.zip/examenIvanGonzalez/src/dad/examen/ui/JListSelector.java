package dad.examen.ui;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Collection;
import java.util.List;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.text.html.HTMLDocument.Iterator;

@SuppressWarnings("serial")
public class JListSelector extends JPanel {
	
	private JList<Object> leftList, rightList;
	private DefaultListModel<Object> modelIzq, modelDer;
	
	public JListSelector() {
		initPanel();
		initComponents();
		initValores();
	}
	
	private void initValores() {
			initIzq();
			initDer();
	}

	public void initDer() {
		modelDer = (DefaultListModel<Object>) rightList.getModel();
		modelDer.removeAllElements();
		modelDer.addElement("Cuarto");
		modelDer.addElement("Quinto");
		modelDer.addElement("Sexto");
	}

	public void initIzq() {
		modelIzq = (DefaultListModel<Object>) leftList.getModel();
		modelIzq.removeAllElements();
		modelIzq.addElement("Primero");
		modelIzq.addElement("Segundo");
		modelIzq.addElement("Tercero");
	}
	
	public void ListarIzq() {
		List<Object> seleccionados = leftList.getSelectedValuesList();
		JOptionPane.showMessageDialog(null,"Elementos seleccionados: "+ seleccionados);
	}
	
	public void ListarDer() {
		List<Object> seleccionados = rightList.getSelectedValuesList();
		JOptionPane.showMessageDialog(null,"Elementos seleccionados: "+ seleccionados);
	}

	private void initPanel() {
		setLayout(new GridBagLayout());
	}

	private void initComponents() {
		leftList = new JList<Object>();
		rightList = new JList<Object>();

		leftList.setModel(new DefaultListModel<Object>());
		rightList.setModel(new DefaultListModel<Object>());

		JScrollPane scrollLeftList = new JScrollPane(leftList);
		JScrollPane scrollRightList = new JScrollPane(rightList);

		Insets margen = new Insets(5, 5, 5, 5);

		JPanel botonesPanel = new JPanel(new GridBagLayout());

		JButton izqAll = new JButton("<<");
		izqAll.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				onIzqAllActionPerformed();
			}
		});
		izqAll.setToolTipText("Todo de derecha a izquierda.");
		
		JButton derSel = new JButton(">");
		derSel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				onDerSelActionPerformed();
			}
		});
		derSel.setToolTipText("Lo seleccionado de izquierda a derecha.");
		
		JButton izqSel = new JButton("<");
		izqSel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				onIzqSelActionPerformed();
			}
		});
		izqSel.setToolTipText("Lo seleccionado de derecha a izquierda.");

		JButton derAll = new JButton(">>");
		derAll.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				onDerAllActionPerformed();
			}
		});
		derAll.setToolTipText("Todo de izquierda a derecha.");

		botonesPanel.add(izqAll, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0, GridBagConstraints.CENTER, GridBagConstraints.BOTH, margen, 0, 0));
		botonesPanel.add(izqSel, new GridBagConstraints(0, 1, 1, 1, 1.0, 0.0, GridBagConstraints.CENTER, GridBagConstraints.BOTH, margen, 0, 0));
		botonesPanel.add(derSel, new GridBagConstraints(0, 2, 1, 1, 1.0, 0.0, GridBagConstraints.CENTER, GridBagConstraints.BOTH, margen, 0, 0));
		botonesPanel.add(derAll, new GridBagConstraints(0, 3, 1, 1, 0.0, 0.0, GridBagConstraints.CENTER, GridBagConstraints.BOTH, margen, 0, 0));

		add(scrollLeftList, new GridBagConstraints(0, 0, 1, 1, 1.0, 1.0, GridBagConstraints.CENTER, GridBagConstraints.BOTH, margen, 0, 0));
		add(botonesPanel, new GridBagConstraints(1, 0, 1, 1, 0.0, 0.0, GridBagConstraints.CENTER, GridBagConstraints.BOTH, margen, 0, 0));
		add(scrollRightList, new GridBagConstraints(2, 0, 1, 1, 1.0, 1.0, GridBagConstraints.CENTER, GridBagConstraints.BOTH, margen, 0, 0));
	}
	
	protected void onIzqSelActionPerformed() {
			List<Object> seleccionados = rightList.getSelectedValuesList();
			for (Object s : seleccionados) {
				modelDer.removeElement(s);
				modelIzq.addElement(s);
			}
	}

	protected void onDerSelActionPerformed() {
		List<Object> seleccionados = leftList.getSelectedValuesList();
		for (Object s : seleccionados) {
			modelIzq.removeElement(s);
			modelDer.addElement(s);
		}
	}

	protected void onDerAllActionPerformed() {
		 //TODO

	}

	protected void onIzqAllActionPerformed() {
		// TODO Auto-generated method stub
		
	}

	@SuppressWarnings("unchecked")
	public Collection<Object> getLeftList() {
		return (Collection<Object>) leftList;
	}
	@SuppressWarnings("unchecked")
	public void setLeftList(Collection<Object> leftList) {
		this.leftList = (JList<Object>) leftList;
	}
	@SuppressWarnings("unchecked")
	public Collection<Object> getRightList() {
		return (Collection<Object>) rightList;
	}
	@SuppressWarnings("unchecked")
	public void setRightList(Collection<Object> rightList) {
		this.rightList = (JList<Object>) rightList;
	}
	
}
