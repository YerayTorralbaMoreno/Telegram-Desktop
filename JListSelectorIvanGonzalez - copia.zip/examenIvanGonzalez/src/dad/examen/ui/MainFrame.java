package dad.examen.ui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

@SuppressWarnings("serial")
public class MainFrame extends JFrame {

	private JListSelector listSelector;
	private JButton initIzq, initDer, listarIzq, listarDer;
	
	public MainFrame(){
		initFrame();
		initComponents();
	}

	private void initFrame() {
		setTitle("Prueba de JListSelector");
		setSize(640, 300);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		setLayout(new BorderLayout());
	}

	private void initComponents() {
		listSelector = new JListSelector();
		getContentPane().add(listSelector, BorderLayout.CENTER);
		
		initIzq = new JButton("Iniciar izquierda");
		initIzq.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				listSelector.initIzq();
			}
		});
		initDer = new JButton("Iniciar derecha");
		initDer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				listSelector.initDer();
			}
		});
		listarIzq = new JButton("Listar izquierda");
		listarIzq.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				listSelector.ListarIzq();
			}
		});
		
		listarDer = new JButton("Listar derecha");
		listarDer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				listSelector.ListarDer();
			}
		});
		
		JPanel botonesPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
			botonesPanel.add(initIzq);
			botonesPanel.add(initDer);
			botonesPanel.add(listarIzq);
			botonesPanel.add(listarDer);
		getContentPane().add(botonesPanel, BorderLayout.SOUTH);
	}
}
