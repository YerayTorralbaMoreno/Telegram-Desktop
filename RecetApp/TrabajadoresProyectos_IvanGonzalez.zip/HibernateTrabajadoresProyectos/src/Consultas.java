import java.util.Iterator;
import org.hibernate.Query;
import org.hibernate.Session;
import classes.Departamentos;
import classes.Proyectos;
import classes.TrabajadorProyecto;
import classes.Trabajadores;
import classes.Trabajadores_Nominas;

public class Consultas {

	@SuppressWarnings("rawtypes")
	public static void main(String[] args){
		
		Session sesion = HibernateUtil.getSessionFactory().openSession();
		sesion.beginTransaction();
		
//		String hqlDel1 = "delete Trabajadores_Nomina t where t.dni=?"; //PUEDO ELIMINAR UNA NOMINA
//		sesion.createQuery( hqlDel1 ) .setString(0,"45897335F").executeUpdate();
//		
//		String hqlDel2 = "delete Trabajadores t where t.dni=?";  //NO PUEDO ELIMINAR UN TRABAJADOR QUE TIENE UNA NOMINA ASOCIADA
//		sesion.createQuery( hqlDel2 ) .setString(0,"45897335F").executeUpdate();

		//TODO Visualizar todos los trabajadores con todos sus datos, incluyendo los de nominas.
		Query consulta8 = sesion.createQuery("from Trabajadores_Nominas tn inner join tn.trabajadores ");
		Iterator iterador8 = consulta8.iterate();
		
		while (iterador8.hasNext()) {
			Object[] objetos =(Object[]) iterador8.next();
			Trabajadores_Nominas trabajadorNomina = (Trabajadores_Nominas) objetos[0];
			Trabajadores trabajador = (Trabajadores) objetos[1];
			System.out. print("Trabajador: " + trabajador.getDni() + " " + trabajador.getNombre() + " " + trabajador.getTelefono() + " " + trabajador.getActivo());
			System.out.println(" - Nomina: " + trabajadorNomina.getSalario() + " " + trabajadorNomina.getTipoContrato() );
			System.out.println("-----------------------------------------------------------------");
		}
		
		//TODO Visualizar todos los trabajadores con salario mayor a uno introducido por teclado y que est�n en activo.
		Query consulta = sesion.createQuery("from Trabajadores_Nominas tn inner join tn.trabajadores t where tn.salario > 1100 and t.activo = 'a'");
		Iterator iterador = consulta.iterate();
		
		while (iterador.hasNext()) {
			Object[] objetos =(Object[]) iterador.next();
			Trabajadores_Nominas trabajadorNomina = (Trabajadores_Nominas) objetos[0];
			Trabajadores trabajador = (Trabajadores) objetos[1];
			System.out. print("Trabajador: " + trabajador.getNombre() );
			System.out.println(" - Nomina: " + trabajadorNomina.getSalario() );
			System.out.println("-----------------------------------------------------------------");
		}
		
		/* TODO Visualizar para un determinado trabajador todos los proyectos en los que ha estado trabajando indicando el
		nombre del proyecto, nombre del departamento al que pertenece el proyecto, fecha de inicio del proyecto y
		fecha de incorporaci�n del trabajador al proyecto.*/
		Query consulta9 = sesion.createQuery("from TrabajadorProyecto tp inner join tp.trabajador t inner join tp.proyecto p inner join p.departamento d");
		
		Iterator iterador9 = consulta9.iterate();
		while (iterador9.hasNext()) {
			Object[] objetos =(Object[]) iterador9.next();
			TrabajadorProyecto trabajadorProyecto = (TrabajadorProyecto) objetos[0];
			Trabajadores trabajador = (Trabajadores) objetos[1];
			Proyectos proyecto = (Proyectos) objetos[2];
			Departamentos departamento = (Departamentos) objetos[3];
			System.out. println("Trabajador: " + trabajador.getNombre() + " " );
			System.out. println("Proyecto: " + "codProyecto - " + proyecto.getCodProyecto() + ", fechaInicioProyecto - " + proyecto.getFechaInicioProyecto() + " " );
			System.out. println("FechaInicioTrabajadorEnElProyecto: " + trabajadorProyecto.getFechaInicioTrabajador() + " " );
			System.out. println("Departamento: " + departamento.getNomDepartamento() + " " );
			System.out.println("-----------------------------------------------------------------");
		}
		
		//TODO Visualizar para un determinado trabajador la cantidad de proyectos que tiene asignado.
		  String consulta1 = "select count(*) from TrabajadorProyecto tp inner join tp.trabajador t where t.dni = ?";
			Query query = sesion.createQuery(consulta1 ).setString(0,"45897335F");
			int cantidad = ((Long) query.uniqueResult()).intValue();
			System.out.println("N�mero de proyectos asignados" + cantidad);
			System.out.println("-----------------------------------------------------------------");
		
		//TODO Visualizar por departamentos los nombres de los departamentos, los nombres de los proyectos que tienen con sus fechas de inicio.
		Query consultaDepartamentos = sesion.createQuery("select nomDepartamento from Departamentos");
		
			String consultaProyectosPorDepartamento = "select nomProyecto from Proyectos p where p.departamento.nomDepartamento = ?";
			Query query2 = sesion.createQuery(consultaProyectosPorDepartamento );

		Iterator iterador1 = consultaDepartamentos.iterate();
		Iterator iterador2;
		
		while (iterador1.hasNext()) {
			String objetos = (String) iterador1.next();
			String nomDepartamento = (String) objetos;
			System.out. println("Departamento: " + nomDepartamento);
			
			query2 = sesion.createQuery(consultaProyectosPorDepartamento ).setString(0,nomDepartamento);
			iterador2 = query2.iterate();
			
				while(iterador2.hasNext()) {
					String objetos2 = (String) iterador2.next();
					String nomProyecto = (String) objetos2;
					System.out. println("	Proyecto: " + nomProyecto);
				}
				
			System.out.println();
		}
		System.out.println("-----------------------------------------------------------------");
		
		//TODO Visualizar los proyectos del departamento x e y
		
		String consultaDepartamento = "select nomDepartamento from Departamentos d where d.nomDepartamento = ? OR d.nomDepartamento = ?";
		Query query7 = sesion.createQuery(consultaDepartamento);
		query7.setString(0, "informatica");
		query7.setString(1, "I+D");
		
		String consultaProyectosPorDepartamentos = "select nomProyecto from Proyectos p where p.departamento.nomDepartamento = ?";
		Query query22 = sesion.createQuery(consultaProyectosPorDepartamentos );

		Iterator iterador11 = query7.iterate();
		Iterator iterador22;
		
		while (iterador11.hasNext()) {
			String objetos = (String) iterador11.next();
			String nomDepartamento = (String) objetos;
			System.out. println("Departamento: " + nomDepartamento);
			
			query22 = sesion.createQuery(consultaProyectosPorDepartamento ).setString(0,nomDepartamento);
			iterador22 = query22.iterate();
			
				while(iterador22.hasNext()) {
					String objetos2 = (String) iterador22.next();
					String nomProyecto = (String) objetos2;
					System.out. println("	Proyecto: " + nomProyecto);
				}
				
			System.out.println();
		}
		System.out.println("-----------------------------------------------------------------");

		
		sesion.getTransaction().commit();
		sesion.close();
	}
}
