import java.sql.Date;
import org.hibernate.Session;
import classes.Departamentos;
import classes.Proyectos;
import classes.TrabajadorProyecto;
import classes.Trabajadores;
import classes.Trabajadores_Nominas;

public class Main {

	public static void main(String[] args) {

		Trabajadores trabajador1 = new Trabajadores();
			trabajador1.setDni("45897335F");
			trabajador1.setNombre("Ivan");
			trabajador1.setTelefono("672088394");
			trabajador1.setActivo('a');

		Trabajadores_Nominas tn1 = new Trabajadores_Nominas();
			tn1.setTrabajador(trabajador1);
			tn1.setSalario(1200);
			tn1.setTipoContrato("Fijo");
				
		Date date = new Date(02,02,2002);	
		
		Departamentos departamento1 = new Departamentos();
			departamento1.setCodDepartamento(1);
			departamento1.setNomDepartamento("I+D");
			departamento1.setTelefono("922774482");
		
		Proyectos proyecto1 = new Proyectos();
			proyecto1.setCodProyecto("1");
			proyecto1.setNomProyecto("Proyecto1");
			proyecto1.setDepartamento(departamento1);
			proyecto1.setFechaInicioProyecto(date);

		Date date2 = new Date(01,01,2001);	
			
		TrabajadorProyecto tp1 = new TrabajadorProyecto();
			tp1.addProyecto(proyecto1);
			tp1.addTrabajador(trabajador1);
			tp1.setFechaInicioTrabajador(date2);
			
		Session sesion = HibernateUtil.getSessionFactory().openSession();
		sesion.beginTransaction();
		sesion.save(trabajador1);
		sesion.save(tn1);
		sesion.save(departamento1);
		sesion.save(proyecto1);
		sesion.save(tp1);
		sesion.getTransaction().commit();
		sesion.close();
	}

}
