package classes;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@SuppressWarnings("serial")
@Entity
public class TrabajadorProyecto implements Serializable{
	
	@Id
	@ManyToOne
	@JoinColumn(name = "dni")
	private Trabajadores trabajador;
	@Id
	@ManyToOne
	@JoinColumn(name = "codProyecto")
	private Proyectos proyecto;
	
	private Date fechaInicioTrabajador;
	
	public Date getFechaInicioTrabajador() {
		return fechaInicioTrabajador;
	}

	public void setFechaInicioTrabajador(Date fechaInicioTrabajador) {
		this.fechaInicioTrabajador = fechaInicioTrabajador;
	}

	public Trabajadores getTrabajador() {
		return trabajador;
	}

	public void setTrabajador(Trabajadores trabajador) {
		this.trabajador = trabajador;
	}

	public Proyectos getProyecto() {
		return proyecto;
	}

	public void setProyecto(Proyectos proyecto) {
		this.proyecto = proyecto;
	}

	public void addProyecto(Proyectos proyecto){
		this.proyecto = proyecto;
	}

	public void addTrabajador(Trabajadores trabajador){
		this.trabajador = trabajador;
	}
}