package classes;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;

import org.hibernate.annotations.GenericGenerator;




@SuppressWarnings("serial")
@Entity
public class Trabajadores_Nominas implements Serializable{

	@Id
    @Column(name="dni", unique=true, nullable=false)
    @GeneratedValue(generator="gen")
	@GenericGenerator(name="gen", strategy="foreign", parameters=@org.hibernate.annotations.Parameter(name="property", value="trabajadores"))    
	private String dni;
	
	@Column(name="salario" , columnDefinition="numeric(18,2)")
	private double salario;
	@Column(name="tipoContrato" , columnDefinition="char(10)")
	private String tipoContrato;
	
	@OneToOne
    @PrimaryKeyJoinColumn
    private Trabajadores trabajadores;
	
	public Trabajadores_Nominas(){}

	public Trabajadores getTrabajador() {
		return trabajadores;
	}

	public void setTrabajador(Trabajadores trabajador) {
		this.trabajadores = trabajador;
	}

	public double getSalario() {
		return salario;
	}

	public void setSalario(double salario) {
		this.salario = salario;
	}

	public String getTipoContrato() {
		return tipoContrato;
	}

	public void setTipoContrato(String tipoContrato) {
		this.tipoContrato = tipoContrato;
	}
	
	
}
