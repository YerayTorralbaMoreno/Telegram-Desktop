package classes;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Trabajadores {

	@Id
	@Column(name="dni" ,length=12)
	private String dni;
	@Column(name="nombre" ,length=30)
	private String nombre;
	@Column(name="telefono" ,length=12)
	private String telefono;
	@Column(name="activo" , columnDefinition="char(1)")
	private char activo;
	
	@OneToOne(mappedBy="trabajadores", cascade=CascadeType.ALL)
    private Trabajadores_Nominas trabajadoresNomina;
	
	public Trabajadores(){}

	public String getDni() {
		return dni;
	}

	public void setDni(String dni) {
		this.dni = dni;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getTelefono() {
		return telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	public char getActivo() {
		return activo;
	}

	public void setActivo(char activo) {
		this.activo = activo;
	}
	
	
	
}
