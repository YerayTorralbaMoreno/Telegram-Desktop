package classes;

import java.sql.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

@Entity
public class Proyectos {
	
	@Id
	@Column(name="codProyecto" ,length=6)
	private String codProyecto;
	@Column(name="nomProyecto" ,length=20)
	private String nomProyecto;
	private Date fechaInicioProyecto;
	@ManyToOne
	@JoinColumn(name = "codDepartamento")
	private Departamentos departamento;
	
	public Proyectos(){}

	public String getCodProyecto() {
		return codProyecto;
	}

	public void setCodProyecto(String codProyecto) {
		this.codProyecto = codProyecto;
	}

	public String getNomProyecto() {
		return nomProyecto;
	}

	public void setNomProyecto(String nomProyecto) {
		this.nomProyecto = nomProyecto;
	}

	public int getDepartamento(Departamentos departamento) {
		return departamento.getCodDepartamento();
	}

	public void setDepartamento(Departamentos departamento) {
		this.departamento = departamento;
	}

	public Date getFechaInicioProyecto() {
		return fechaInicioProyecto;
	}

	public void setFechaInicioProyecto(Date fechaInicioProyecto) {
		this.fechaInicioProyecto = fechaInicioProyecto;
	}
}
